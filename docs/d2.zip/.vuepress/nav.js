module.exports = [
    //格式一：直接跳转，'/'为不添加路由，跳转至首页 https://emojixd.com/subgroup/sky%20&%20weather
    {text: '🌈首页', link: '/'},


    {
        text: '⭐优质项目', link: "/d1/三天肝完设计模式的面试题，面试再不怕设计模式的问题了"
    },
    {
        text: '⭐小孟的开发生活', link: "/d2/我帮小弟提高了10w收入！"

    },
    {
        text: '💎钻石VIP',link: "/d3/java 培训"
    },
    {
        text: '⭐面试大全',link: "/d4/demo"
    },
    {
        text: '⭐软件工具大全',link: "/d5/demo"
    },
    {
        text: '⭐定制开发',link: "/d6/demo"
    },
]