module.exports = {
    "/d1/": [

        {
            title: '三天肝完设计模式的面试题，面试再不怕设计模式的问题了',
            sidebarDepth: 2,
            sidebar: 'auto',
            path: '三天肝完设计模式的面试题，面试再不怕设计模式的问题了',
            collapsable: false
        },

        {
            title: '二分法查找（binarySearch）',
            sidebarDepth: 2,
            sidebar: 'auto',
            path: '二分法查找（binarySearch）',
            collapsable: false
        },

        {
            title: '冒泡排序（Bubble Sort）',
            sidebarDepth: 2,
            sidebar: 'auto',
            path: '冒泡排序（Bubble Sort）',
            collapsable: false
        },

        {
            title: '十大大厂高频算法题',
            sidebarDepth: 2,
            sidebar: 'auto',
            path: '十大大厂高频算法题',
            collapsable: false
        },

        {
            title: '快速排序（Selection Sort）',
            sidebarDepth: 2,
            sidebar: 'auto',
            path: '快速排序（Selection Sort）',
            collapsable: false
        },
        {
            title: '插入排序（InsertionSort）',
            sidebarDepth: 2,
            sidebar: 'auto',
            path: '插入排序（InsertionSort）',
            collapsable: false
        }
    ],
    "/d2/": [

        {
            title: '我帮小弟提高了10w收入！',
            sidebarDepth: 2,
            sidebar: 'auto',
            path: '我帮小弟提高了10w收入！',

            collapsable: false

        },
        {
            title: '蓝桥杯有必要参赛吗？',
            sidebarDepth: 2,
            sidebar: 'auto',
            path: '蓝桥杯有必要参赛吗？',
            collapsable: false

        }, {
            title: '麻了，3个offer不知道选哪个？',
            sidebarDepth: 2,
            sidebar: 'auto',
            path: '麻了，3个offer不知道选哪个？',
            collapsable: false

        }
    ],
    "/d3/": [

        {
            title: 'java java 培训',
            sidebarDepth: 2,
            sidebar: 'auto',
            path: 'java 培训',
            collapsable: false

        }
    ],
    "/d4/": [

        {
            title: 'Demo',
            sidebarDepth: 2,
            sidebar: 'auto',
            path: 'demo',
            collapsable: false

        }
    ],
    "/d5/": [

        {
            title: 'Demo',
            sidebarDepth: 2,
            sidebar: 'auto',
            path: 'demo',
            collapsable: false

        }
    ],
    "/d6/": [

        {
            title: 'Demo',
            sidebarDepth: 2,
            sidebar: 'auto',
            path: 'demo',
            collapsable: false

        }
    ]
}