module.exports = [
    //格式一：直接跳转，'/'为不添加路由，跳转至首页 https://emojixd.com/subgroup/sky%20&%20weather
    { text: '🌈首页', link: '/' },

    //格式三：跳转至外部网页，需http/https前缀
    { text: '⭐学习路线',
        items: [
            {text: 'String项目分享', link: '/baodian/zero/'},
            {text: '剑指offer', link: '/baodian/zero/'},
            {text: 'LeeCode', link: '/baodian/high/'}
        ]
    },
    { text: '⭐优质项目',
        items: [
            {text: 'SpringBoot项目实战', link: '/baodian/zero/'},
            {text: 'SSM项目实战', link: '/baodian/zero/'},
            {text: 'Servlet优质项目', link: '/baodian/high/'},
            {text: '微服务项目', link: '/baodian/high/'},
            {text: 'Python项目实战', link: '/baodian/high/'},
            {text: '小程序优质项目', link: '/baodian/high/'},
        ]
    },
    { text: '⭐LeetCode算法',
        items: [
            {text: '基础的LeetCode', link: '/baodian/zero/'},
        ]
    },
    { text: '⭐小孟的开发生活',
        items: [
            {text: '程序员小孟的开发分享', link: '/baodian/zero/'},
            {text: '小孟的生活', link: '/baodian/zero/'},
            {text: '职场点点滴滴', link: '/baodian/zero/'},
        ]
    },
    { text: '💎钻石VIP',
        items: [
            {text: 'VIP项目列表', link: '/baodian/zero/'},
        ]
    },
    { text: '⭐软件开发工具',
        items: [
            {text: '开发工具下载', link: '/baodian/zero/'},
        ]
    },
    { text: '⭐职场面试',
        items: [
            {text: '应届生面试', link: '/baodian/zero/'},
            {text: '社招面试', link: '/baodian/zero/'},
        ]
    },
    { text: '⭐计算机408学习',
        items: [
            {text: '数据结构', link: '/baodian/zero/'},
            {text: '计算机网络', link: '/baodian/zero/'},
            {text: '计算机组成原理', link: '/baodian/zero/'},
            {text: '操作系统', link: '/baodian/zero/'},
        ]
    },
]