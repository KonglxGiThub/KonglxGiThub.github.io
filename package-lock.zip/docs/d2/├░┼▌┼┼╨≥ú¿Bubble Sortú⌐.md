---
title: 冒泡排序（Bubble Sort）
date: 2017-12-28
sidebar: 'auto'
categories:
- 算法
---
### 一、什么是冒泡排序
#### 1.概念
冒泡排序（Bubble Sort），是一种[计算机科学](https://baike.baidu.com/item/%E8%AE%A1%E7%AE%97%E6%9C%BA%E7%A7%91%E5%AD%A6/9132?fromModule=lemma_inlink)领域的较简单的[排序算法](https://baike.baidu.com/item/%E6%8E%92%E5%BA%8F%E7%AE%97%E6%B3%95/5399605?fromModule=lemma_inlink)。
它重复地走访过要排序的元素列，依次比较两个相邻的[元素](https://baike.baidu.com/item/%E5%85%83%E7%B4%A0/9563223?fromModule=lemma_inlink)，如果顺序错误就把他们交换过来。走访元素的工作是重复地进行，直到没有相邻元素需要交换，也就是说该元素列已经排序完成。
冒泡排序算法是所有排序算法中最简单的，在生活中应该也会看到气泡从水里面出来时，越到水面上气泡就会变的越大。在物理上学气压的时候好像也看到过这种现象；其实理解冒泡排序就可以根据这种现象来理解：每一次遍历，都把大的往后面排（当然也可以把小的往后面排），所以每一次都可以把无序中最大的（最小）的元素放到无序的最后面（或者说有序元素的最开始）；
[
](https://blog.csdn.net/weixin_43419883/article/details/88418730)
#### 2.算法原理
冒泡[排序算法](https://baike.baidu.com/item/%E6%8E%92%E5%BA%8F%E7%AE%97%E6%B3%95/5399605?fromModule=lemma_inlink)的原理如下： 

1. 比较相邻的元素。如果第一个比第二个大，就交换他们两个。 
2. 对每一对相邻元素做同样的工作，从开始第一对到结尾的最后一对。在这一点，最后的元素应该会是最大的数。 
3. 针对所有的元素重复以上的步骤，除了最后一个。 
4. 持续每次对越来越少的元素重复上面的步骤，直到没有任何一对数字需要比较
#### 3.算法实现
```java
public static void bubbleSort(int arr[]) {

    for(int i =0 ; i<arr.length-1 ; i++) { 

        for(int j=0 ; j<arr.length-1-i ; j++) {  

            if(arr[j]>arr[j+1]) {
                int temp = arr[j];

                arr[j]=arr[j+1];

                arr[j+1]=temp;
            }
        }    
    }
}
```
### 二、冒泡排序算法优化
#### 1.针对问题
数据的顺序排好之后，冒泡算法仍然会继续进行下一轮的比较，直到arr.length-1次，后面的比较没有意义的。
#### 2.方案
在下一轮比较时，只需比较到上一轮比较中，最后一次发生交换的位置即可。因为后面的所有元素都没有发生过交换，必然已经有序了。
#### 3.算法实现
```java
import java.util.Arrays;

public class BubbleSort {


    public static void bubbleSort(int[] arr) {
        if (arr == null || arr.length < 2) {
            return;
        }
        for (int end = arr.length - 1; end > 0; end--) {
            for (int i = 0; i < end; i++) {
                if (arr[i] > arr[i + 1]) {
                    swap(arr, i, i + 1);
                }
            }
        }
    }

    // 交换arr的i和j位置上的值
    public static void swap(int[] arr, int i, int j) {
        int tmp = arr[i];
        arr[i] = arr[j];
        arr[j] = tmp;
    }

    // for test
    public static void comparator(int[] arr) {
        Arrays.sort(arr);
    }

    // for test
    public static int[] generateRandomArray(int maxSize, int maxValue) {
        int[] arr = new int[(int) ((maxSize + 1) * Math.random())];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int) ((maxValue + 1) * Math.random()) - (int) (maxValue * Math.random());
        }
        return arr;
    }

    // for test
    public static int[] copyArray(int[] arr) {
        if (arr == null) {
            return null;
        }
        int[] res = new int[arr.length];
        for (int i = 0; i < arr.length; i++) {
            res[i] = arr[i];
        }
        return res;
    }

    // for test
    public static boolean isEqual(int[] arr1, int[] arr2) {
        if ((arr1 == null && arr2 != null) || (arr1 != null && arr2 == null)) {
            return false;
        }
        if (arr1 == null && arr2 == null) {
            return true;
        }
        if (arr1.length != arr2.length) {
            return false;
        }
        for (int i = 0; i < arr1.length; i++) {
            if (arr1[i] != arr2[i]) {
                return false;
            }
        }
        return true;
    }

    // for test
    public static void printArray(int[] arr) {
        if (arr == null) {
            return;
        }
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }

    // for test
    public static void main(String[] args) {
        int testTime = 500000;
        int maxSize = 100;
        int maxValue = 100;
        boolean succeed = true;
        for (int i = 0; i < testTime; i++) {
            int[] arr1 = generateRandomArray(maxSize, maxValue);
            int[] arr2 = copyArray(arr1);
            bubbleSort(arr1);
            comparator(arr2);
            if (!isEqual(arr1, arr2)) {
                succeed = false;
                break;
            }
        }
        System.out.println(succeed ? "Nice!" : "Fucking fucked!");

        int[] arr = generateRandomArray(maxSize, maxValue);
            printArray(arr);
            bubbleSort(arr);
            printArray(arr);
            }


            }

```


### 三、冒泡排序算法特点
#### 1.时间复杂度
若文件的初始状态是正序的，一趟扫描即可完成排序。所需的关键字比较次数![](https://cdn.nlark.com/yuque/0/2022/svg/360337/1666672235152-e9047a26-3f36-4ae9-ada0-b55738f7c3f9.svg#clientId=u2becf6ad-5de3-4&crop=0&crop=0&crop=1&crop=1&from=paste&id=u0b207ecf&margin=%5Bobject%20Object%5D&originHeight=19&originWidth=16&originalType=url&ratio=1&rotation=0&showTitle=false&status=done&style=none&taskId=ua18de513-4401-4267-bb2f-f0af32205b8&title=)和记录移动次数![](https://cdn.nlark.com/yuque/0/2022/svg/360337/1666672235175-e3ee09f2-bef2-456f-ac6e-d24a87d532ba.svg#clientId=u2becf6ad-5de3-4&crop=0&crop=0&crop=1&crop=1&from=paste&id=Hr9mE&margin=%5Bobject%20Object%5D&originHeight=18&originWidth=22&originalType=url&ratio=1&rotation=0&showTitle=false&status=done&style=none&taskId=uc0bba299-11c5-4411-9bd5-e74a40f6880&title=) 均达到最小值：   
![](https://cdn.nlark.com/yuque/0/2022/svg/360337/1666672235164-d3d6e311-91be-4ddb-a59e-ff8c84c70fa5.svg#clientId=u2becf6ad-5de3-4&crop=0&crop=0&crop=1&crop=1&from=paste&id=ubb939024&margin=%5Bobject%20Object%5D&originHeight=21&originWidth=118&originalType=url&ratio=1&rotation=0&showTitle=false&status=done&style=none&taskId=u9a936833-db3d-4d6a-8be6-e417a621782&title=)，![](https://cdn.nlark.com/yuque/0/2022/svg/360337/1666672235157-66c3fadb-1cf9-454a-999f-d02c47dcdad9.svg#clientId=u2becf6ad-5de3-4&crop=0&crop=0&crop=1&crop=1&from=paste&id=u34e13c20&margin=%5Bobject%20Object%5D&originHeight=20&originWidth=85&originalType=url&ratio=1&rotation=0&showTitle=false&status=done&style=none&taskId=ua5f52178-106f-4467-a0e5-2a6462a5257&title=)。
所以，冒泡排序最好的[时间复杂度](https://baike.baidu.com/item/%E6%97%B6%E9%97%B4%E5%A4%8D%E6%9D%82%E5%BA%A6?fromModule=lemma_inlink)为![](https://cdn.nlark.com/yuque/0/2022/svg/360337/1666672235149-4ab4e2da-828f-4583-ba7d-7387cfe5750f.svg#clientId=u2becf6ad-5de3-4&crop=0&crop=0&crop=1&crop=1&from=paste&id=u52b5515a&margin=%5Bobject%20Object%5D&originHeight=24&originWidth=45&originalType=url&ratio=1&rotation=0&showTitle=false&status=done&style=none&taskId=uadff251d-4073-4fc2-b092-6c381079af8&title=)。
若初始文件是反序的，需要进行![](https://cdn.nlark.com/yuque/0/2022/svg/360337/1666672235492-8df38c46-ebd9-4c45-99f5-f6a616eb78ec.svg#clientId=u2becf6ad-5de3-4&crop=0&crop=0&crop=1&crop=1&from=paste&id=uc4c0431d&margin=%5Bobject%20Object%5D&originHeight=19&originWidth=49&originalType=url&ratio=1&rotation=0&showTitle=false&status=done&style=none&taskId=uc58ac4be-8b66-48c9-b9e1-f607ce7a9c5&title=)趟排序。每趟排序要进行 ![](https://cdn.nlark.com/yuque/0/2022/svg/360337/1666672235493-24e96842-5234-4633-8c23-7271ebad7d95.svg#clientId=u2becf6ad-5de3-4&crop=0&crop=0&crop=1&crop=1&from=paste&id=plzX6&margin=%5Bobject%20Object%5D&originHeight=19&originWidth=45&originalType=url&ratio=1&rotation=0&showTitle=false&status=done&style=none&taskId=ua57df39b-2d1a-475c-94d0-6ee9b419c13&title=)次关键字的比较(1≤i≤n-1)，且每次比较都必须移动记录三次来达到交换记录位置。在这种情况下，比较和移动次数均达到最大值： 
![](https://cdn.nlark.com/yuque/0/2022/svg/360337/1666672235524-92a4234a-ebe3-4c7c-8050-721c89520f83.svg#clientId=u2becf6ad-5de3-4&crop=0&crop=0&crop=1&crop=1&from=paste&id=u56937f9b&margin=%5Bobject%20Object%5D&originHeight=48&originWidth=240&originalType=url&ratio=1&rotation=0&showTitle=false&status=done&style=none&taskId=u0e6ab324-2aac-4a22-9b92-9b73c7af5c8&title=)
![](https://cdn.nlark.com/yuque/0/2022/svg/360337/1666672235500-cc66e1ca-610f-4bc4-9075-f37b050ba346.svg#clientId=u2becf6ad-5de3-4&crop=0&crop=0&crop=1&crop=1&from=paste&id=u908ca136&margin=%5Bobject%20Object%5D&originHeight=48&originWidth=259&originalType=url&ratio=1&rotation=0&showTitle=false&status=done&style=none&taskId=u4b272fdb-c43f-41f9-9a9f-cb39585990b&title=)
冒泡排序的最坏时间复杂度为![](https://cdn.nlark.com/yuque/0/2022/svg/360337/1666672235521-2d40abba-5aa3-4ce8-864b-e2cf68d34794.svg#clientId=u2becf6ad-5de3-4&crop=0&crop=0&crop=1&crop=1&from=paste&id=u456ff0dc&margin=%5Bobject%20Object%5D&originHeight=27&originWidth=54&originalType=url&ratio=1&rotation=0&showTitle=false&status=done&style=none&taskId=ua480fb6e-a9d4-4df4-818d-7c3cb1d1444&title=)。
综上，因此冒泡排序总的平均时间复杂度为![](https://cdn.nlark.com/yuque/0/2022/svg/360337/1666672235801-8d24168e-4b38-4ec6-9daa-a147f1043ae6.svg#clientId=u2becf6ad-5de3-4&crop=0&crop=0&crop=1&crop=1&from=paste&id=ued6fa67d&margin=%5Bobject%20Object%5D&originHeight=27&originWidth=54&originalType=url&ratio=1&rotation=0&showTitle=false&status=done&style=none&taskId=u03afbcc6-3c6a-4da9-a5db-a3cdb24b0ee&title=)。 
#### 2.[空间复杂度](https://so.csdn.net/so/search?q=%E7%A9%BA%E9%97%B4%E5%A4%8D%E6%9D%82%E5%BA%A6&spm=1001.2101.3001.7020)
空间复杂度就是在交换元素时那个临时变量所占的内存空间；
最优的空间复杂度就是开始元素顺序已经排好了，则空间复杂度为：0；
最差的空间复杂度就是开始元素逆序排序了，则空间复杂度为：O(n)；
平均的空间复杂度为：O(1)；
最优时间复杂度为： n
#### 3.稳定性
冒泡排序就是把小的元素往前调或者把大的元素往后调。比较是相邻的两个元素比较，交换也发生在这两个元素之间。所以，如果两个元素相等，是不会再交换的；如果两个相等的元素没有相邻，那么即使通过前面的两两交换把两个相邻起来，这时候也不会交换，所以相同元素的前后顺序并没有改变，所以冒泡排序是一种[稳定排序](https://baike.baidu.com/item/%E7%A8%B3%E5%AE%9A%E6%8E%92%E5%BA%8F/4975546?fromModule=lemma_inlink)算法。
